# Dataset for Raman demo

The data needed for the demos can be downloaded [here](https://stanford.box.com/v/bacteria-ID), and you should have 10 files: `X_reference.npy`, `y_reference.npy`, `X_clinical.npy`, and `y_clinical.npy`.